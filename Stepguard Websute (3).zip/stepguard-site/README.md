# Stepguard — Website

Static marketing site for Stepguard. Single-page, no build step, no dependencies.

## Structure

```
.
├── index.html        # the entire site
├── assets/
│   └── logo.jpeg     # brand mark
├── LICENSE
└── .gitignore
```

Fonts (Space Grotesk, Manrope, JetBrains Mono) load from Google Fonts at runtime — no local font files needed.

## Run locally

Just open `index.html` in a browser. Or serve the folder:

```bash
# Python 3
python3 -m http.server 8000

# Node
npx serve .
```

Then visit <http://localhost:8000>.

## Deploy

This is a static site — drop it on anything that serves files.

### GitHub Pages

1. Create a new repo on GitHub.
2. From this folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
3. In the repo on GitHub → **Settings → Pages** → Source: `Deploy from a branch` → Branch: `main` / `/ (root)` → Save.
4. Site goes live at `https://<you>.github.io/<repo>/` within a minute or two.

### Netlify / Vercel / Cloudflare Pages

Point any of them at the repo. No build command, publish directory is the repo root.

## Editing

All markup, CSS, and JS live in `index.html`. Sections are commented — search for `<!-- ` to jump around.

To swap the logo, replace `assets/logo.jpeg` (keep the filename, or update the three `<img src="assets/logo.jpeg">` references in `index.html`).
